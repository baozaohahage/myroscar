var searchData=
[
  ['description',['description',['../structserial_1_1_port_info.html#a2ba37dd33d47b554aef5c15c1fe8b872',1,'serial::PortInfo']]]
];
