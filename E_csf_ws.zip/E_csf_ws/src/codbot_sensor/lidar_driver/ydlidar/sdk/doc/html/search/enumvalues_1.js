var searchData=
[
  ['max_5fscan_5fnodes',['MAX_SCAN_NODES',['../classydlidar_1_1_y_dlidar_driver.html#a13a4f2dc4067b43794b2c47c06d5d27aa3db6fc46c7ce55cdf3a968b70e96374a',1,'ydlidar::YDlidarDriver']]]
];
